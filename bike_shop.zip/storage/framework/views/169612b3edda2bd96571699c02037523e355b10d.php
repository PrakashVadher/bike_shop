<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Admin - Bike Shop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no"
    />
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <link rel="icon" href="assets/images/favicon.ico">

    <meta name="msapplication-tap-highlight" content="no">

<link href="<?php echo e(URL::to('/')); ?>/back_end_admin/assets/style.css" rel="stylesheet">
 <?php echo $__env->yieldContent('stylesheets'); ?>
</head>
    <body>
        <div class="app-container app-theme-gray app-sidebar-full">
                <div class="app-main">
                    <?php echo $__env->make('layouts.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="app-main__outer">
                        <div class="app-main__inner">
                            <?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>     
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                  <?php echo e(session('success')); ?>

                                </div> 
                            <?php endif; ?>               
                            <div class="app-inner-layout app-inner-layout-page">
                                <div class="app-inner-layout__wrapper">
                                    <div class="app-inner-layout__content">
                                        <div class="tab-content">
                                            <div class="container-fluid">
                                                <?php echo $__env->yieldContent('content'); ?>
                                            </div>
                                        </div>
                                    </div>                            
                                </div>
                            </div>
                        </div>
                        <?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <!-- <?php echo $__env->make('layouts.admin_ui_theme_settings', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
        </div>
        <!-- <?php echo $__env->make('layouts.admin_server_status', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
        <script type="text/javascript" src="<?php echo e(URL::to('/')); ?>/back_end_admin/assets/scripts/main.js"></script>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
